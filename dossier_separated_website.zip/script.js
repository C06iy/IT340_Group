const featuredSites = [
    { id: 1, title: 'retro_art_gallery', user: 'cyber_artist', tag: 'Art & Design', color: '#1e1b4b', icon: 'fa-palette' },
    { id: 2, title: 'dev_resume', user: 'alex_rivers', tag: 'Software & Code', color: '#064e3b', icon: 'fa-code' },
    { id: 3, title: 'indie_musician_hub', user: 'synth_wave_99', tag: 'Music & Audio', color: '#701a75', icon: 'fa-music' },
    { id: 4, title: 'written_dossier', user: 'clara_novels', tag: 'Writing & Research', color: '#78350f', icon: 'fa-book' },
    { id: 5, title: 'arcade_game_dev', user: 'pixel_master', tag: 'Game Design', color: '#14532d', icon: 'fa-gamepad' },
    { id: 6, title: 'photo_journal', user: 'lens_craft', tag: 'Photography', color: '#831843', icon: 'fa-camera' }
];

window.onload = function() {
    if (document.getElementById('featured-grid')) {
        renderFeaturedGrid(featuredSites);
    }
};

function renderFeaturedGrid(list) {
    const grid = document.getElementById('featured-grid');
    if (!grid) return;
    grid.innerHTML = '';
    const countEl = document.getElementById('featured-count');
    if (countEl) countEl.innerText = list.length;

    list.forEach(site => {
        const card = document.createElement('div');
        card.className = 'retro-card rounded p-3 cursor-pointer hover:border-rose-400 transition-all flex flex-col justify-between';
        card.onclick = () => showToast(`Selected @${site.user}'s portfolio`);
        card.innerHTML = `
            <div class="h-24 rounded flex items-center justify-center mb-2 text-3xl border border-slate-700" style="background-color: ${site.color}">
                <i class="fa-solid ${site.icon} text-white/80"></i>
            </div>
            <div>
                <h4 class="font-mono text-xs font-bold text-rose-300 truncate">${site.title}</h4>
                <p class="text-[10px] text-slate-400">by @${site.user}</p>
            </div>
            <span class="mt-2 text-[9px] bg-slate-900 border border-slate-700 text-slate-300 px-1.5 py-0.5 rounded inline-block w-fit">
                ${site.tag}
            </span>
        `;
        grid.appendChild(card);
    });
}

function handleGlobalSearch(query) {
    const q = query.toLowerCase().trim();
    if (!q) {
        renderFeaturedGrid(featuredSites);
        return;
    }
    const filtered = featuredSites.filter(s => 
        s.title.toLowerCase().includes(q) || 
        s.user.toLowerCase().includes(q) || 
        s.tag.toLowerCase().includes(q)
    );
    renderFeaturedGrid(filtered);
}

function handleAuthSubmit(e, mode) {
    e.preventDefault();
    showToast(mode === 'login' ? 'Successfully logged in! Redirecting...' : 'Account registered successfully! Redirecting...');
    setTimeout(() => {
        window.location.href = 'index.html';
    }, 1500);
}

function showToast(msg) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    document.getElementById('toast-message').innerText = msg;
    toast.classList.remove('translate-y-20', 'opacity-0', 'pointer-events-none');
    setTimeout(() => {
        toast.classList.add('translate-y-20', 'opacity-0', 'pointer-events-none');
    }, 3000);
}
